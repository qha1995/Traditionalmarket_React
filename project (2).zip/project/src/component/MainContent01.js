
const MainContent01 = () => {
    return (
        <section className=" MainContent csc">
     메인 콘텐츠 입니다.
        </section>
    )
}
export default  MainContent01;