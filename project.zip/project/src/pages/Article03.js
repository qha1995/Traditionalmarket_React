import React from 'react'

const Article = ({ content, num }) => {
    return (
        <article className='Article'>
        <div className="tit">
        <strong>게시판3</strong>
        </div>
 



    
    </article>

    )
}

export default Article;