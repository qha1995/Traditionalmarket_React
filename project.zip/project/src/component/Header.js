import { Link } from 'react-router-dom';


const NAVLINK = [
    { id: 1, menu: "sub01", link: '/sub01' },
    { id: 2, menu: "sub02", link: '/sub02' },
    { id: 3, menu: "sub03", link: '/sub03' },
    { id: 4, menu: "sub04", link: '/sub04' },

]

const Header = () => {


 
    return (
        
        <header className="Header">
         

            <div className="hd_wrap">
            <h1>
                    <a href="/" >
                        로고
                    </a>
                </h1>
                <nav className="Gnb">
                    <ul>
                        {
                            NAVLINK.map((it, idx) => {
                                return (
                                    <li key={it.id}>
                                        <Link to={it.link}>{it.menu}</Link>
                                    </li>
                                )
                            })
                        }
                    </ul>
                </nav>
                <div className="top_service">
                    <ul className="project">                
                        <li><a href="#!">로그인</a></li>
                        <li><a href="#!">회원가입</a></li>
                        <li><a href="#!">상담센터</a></li>
               
                    </ul>
                  
              
                </div>
            </div>
        </header>
    )
}

export default Header;