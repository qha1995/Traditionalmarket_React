import React from 'react'

const Wrapper = ({ children }) => {
    return (
        <div className='Wrapper'>
            {children}
        </div>
    )
}

export default Wrapper