

const Footer = () => {
    return (
        <footer className="Footer">
footer
        </footer>
    )
}

export default Footer