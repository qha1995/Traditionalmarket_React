import React from 'react';
import MainContent01 from './MainContent01';

const Main = () => {

    return (
        <main className='Main'>
   
            <MainContent01/>
    
        </main>
    )
}

export default Main

